﻿namespace CSharpKoans.Base
{
	public class Koans
	{
		protected object _
		{
			get;
			set;
		}
	}
}